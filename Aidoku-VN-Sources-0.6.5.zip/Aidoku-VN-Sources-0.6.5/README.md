# Aidoku Sources
Kho lưu trữ này lưu trữ các nguồn công khai có thể cài đặt trực tiếp thông qua ứng dụng Aidoku.

## Cách sử dụng
[Nhấn vào đây để thêm Source](https://aidoku.app/add-source-list/?url=https://raw.githubusercontent.com/JustaTama/Aidoku-VN-Sources/gh-pages/).
Khi nhấn vào sẽ tự chuyển tiếp qua ứng dụng Aidoku.

## Contributing
Contributions are welcome!

See [CONTRIBUTING.md](./.github/CONTRIBUTING.md) to get started with development.

## License
Licensed under either of Apache License, version 2.0 or MIT license at your option.

Unless you explicitly state otherwise, any contribution intentionally submitted for inclusion in this repository by you, as defined in the Apache-2.0 license, shall be dual licensed as above, without any additional terms or conditions.
